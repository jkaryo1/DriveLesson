Jon Karyo
jkaryo1
Assignment 1

For Part C, I stayed relatively close to the original design, save a few changes
that I made.

First off, I chose to stray from the styling of the design document in order to
create a more attractive, newer-looking display.

In regards to the DatePicker, I chose to automatically populate the TextView
when the start button is pressed instead of using a DatePicker. This is because
both options end with the same result, however the automatic population is
easier for the user.

Also, I made sure that the stop button is disabled until the start button is
pressed, at which point the start button is disabled until the stop button is
pressed. When the start button is pressed, whatever is in the Total Time box is
cleared until the stop button is pressed. This causes the elapsed time to be
passed into the TextView.

Lastly, I decided to show elapsed time slightly differently than the design.
Instead of just showing hours passed as a decimal, I chose to show number of
hours and minutes, as I find that to be easier to read than a decimal of the
number of hours.
